<?php 
function alpha_child_sc_sty(){
	wp_enqueue_style( "alpha-style", get_parent_theme_file_uri( "/style.css" ));
}
add_action("wp_enqueue_scripts","alpha_child_sc_sty");



function alpha_child_sc_sty_ch(){
	wp_dequeue_style( 'alpha-css');
	//wp_deregister_style('alpha-css');

	wp_enqueue_style( 'alpha-css', get_theme_file_uri("/assetes/alpha.css") );
}
add_action("wp_enqueue_scripts","alpha_child_sc_sty_ch",11);



   function alpha_header_image_load(){
  if(is_front_page()){
    if(current_theme_supports("custom-header")){
      ?>
      <style> 
              .header{
                background-image: url(<?php echo header_image(); ?>);
              }
            .heading{
            color:#<?php echo get_header_textcolor(); ?>;
           }
           <?php 

           if(!display_header_text() ){
            echo "display:none";
           }
           ?>
       </style>
    <?php }
  }
}
add_action("wp_head","alpha_header_image_load",11);